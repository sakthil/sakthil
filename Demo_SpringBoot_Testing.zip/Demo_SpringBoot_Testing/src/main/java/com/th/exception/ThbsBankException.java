package com.th.exception;

public class ThbsBankException extends Exception {
	private static final long serialVersionUID = 1L;

	public ThbsBankException(String message) {
		super(message);
	}
}
